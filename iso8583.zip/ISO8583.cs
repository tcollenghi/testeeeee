﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Iso8583
{
    public class ISO8583
    {
        // Get the overall purpose of the message.
        public string GetIso8583Purpose(string iso8583)
        {
            string str1st = iso8583.Substring(1, 1);
            if (str1st == "0")
            {
                return "Reserved by ISO";
            }
            else if (str1st == "1")
            {
                return "Authorization";
            }
            else if (str1st == "2")
            {
                return "Financial";
            }
            else if (str1st == "3")
            {
                return "File actions";
            }
            else if (str1st == "4")
            {
                return "Reversal";
            }
            else if (str1st == "5")
            {
                return "Reconciliation";
            }
            else if (str1st == "6")
            {
                return "Administrative";
            }
            else if (str1st == "7")
            {
                return "Free collection";
            }
            else if (str1st == "8")
            {
                return "Network management";
            }
            else if (str1st == "9")
            {
                return "Reserved by ISO";
            }
            else
            {
                return "";
            }
            return str1st;
        }

        // Return the iso8583 version
        public string GetIso8583Version(string iso8583)
        {
            string str1st = iso8583.Substring(0, 1);
            if (str1st == "0")
            {
                return "1987";
            }
            else if (str1st == "1")
            {
                return "1993";
            }
            else if (str1st == "2")
            {
                return "2003";
            }
            else if (str1st == "3")
            {
                return "2003";
            }
            else if (str1st == "4")
            {
                return "2003";
            }
            else if (str1st == "5")
            {
                return "2003";
            }
            else if (str1st == "6")
            {
                return "2003";
            }
            else if (str1st == "7")
            {
                return "2003";
            }
            else if (str1st == "8")
            {
                return "2003";
            }
            else if (str1st == "9")
            {
                return "2003";
            }
            else
            {
                return "";
            }
            return str1st;
        }

        // Return the iso8583 message value
        public string GetMessageValue(string iso8583, int startIndex, int len)
        {
            return iso8583.Substring(startIndex, len);
        }

        // Generate iso8583 0200 message with some content (just for testing)
        // and return the message
        public string Generate0200Message()
        {
            var messageIso = "0200";
            messageIso += "01";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000";
            messageIso += "000000"; // End of message
            return messageIso;
        }

        // Return the iso8583 message function code
        public string GetMessageFunction(string iso8583)
        {
            string str1st = iso8583.Substring(2, 1);
            if (str1st == "0")
            {
                return "Request";
            }
            else if (str1st == "1")
            {
                return "Request Response";
            }
            else if (str1st == "2")
            {
                return "Advice";
            }
            else if (str1st == "3")
            {
                return "Advice Response";
            }
            else if (str1st == "4")
            {
                return "Notification";
            }
            else if (str1st == "5")
            {
                return "Notification Response";
            }
            else if (str1st == "6")
            {
                return "Instruction";
            }
            else if (str1st == "7")
            {
                return "Instruction Acknowledgement";
            }
            else if (str1st == "8")
            {
                return "Reserved for ISO use";
            }
            else if (str1st == "9")
            {
                return "Reserved for ISO use";
            }
            else
            {
                return "";
            }
        }

        // Return the iso8583 message origin
        public string GetMessageOrigin(string iso8583)
        {
            string str1st = iso8583.Substring(3, 1);
            if (str1st == "0")
            {
                return "Acquirer";
            }
            else if (str1st == "1")
            {
                return "Acquirer Repeate";
            }
            else if (str1st == "2")
            {
                return "Issuer";
            }
            else if (str1st == "3")
            {
                return "Issuer Repeate";
            }
            else if (str1st == "4")
            {
                return "Other";
            }
            else if (str1st == "5")
            {
                return "Other repeat";
            }
            else if (str1st == "6")
            {
                return "Reserved for ISO use";
            }
            else if (str1st == "7")
            {
                return "Reserved for ISO use";
            }
            else if (str1st == "8")
            {
                return "Reserved for ISO use";
            }
            else if (str1st == "9")
            {
                return "Reserved for ISO use";
            }
            else
            {
                return "";
            }
        }

        public string GetMessageType(string iso8583)
        {
            string str1st = iso8583.Substring(4, 4);
            if (str1st == "0100")
            {
                return "Authorization Request";
            }
            else if (str1st == "0200")
            {
                return "Acquirer Financial Request";
            }
            else if (str1st == "0800")
            {
                return "Network Management Request";
            }
            else if (str1st == "0810")
            {
                return "Network Management Response";
            }
            return string.Empty;
        }

        public string GetMessageBitmapSecondaryBitmap(string iso8583)
        {
            string strBitmap = "";
            for (int i = 0; i < 32; i++)
            {
                strBitmap += ConvertHexadecimalToBinary(iso8583.Substring(i * 2, 2));
            }
            return strBitmap;
        }

        //convert hexadecimal to binary
        public string ConvertHexadecimalToBinary(string hexadecimal)
        {
            string binary = "";
            for (int i = 0; i < hexadecimal.Length; i++)
            {
                switch (hexadecimal[i])
                {
                    case '0':
                        binary += "0000";
                        break;

                    case '1':
                        binary += "0001";
                        break;

                    case '2':
                        binary += "0010";
                        break;

                    case '3':
                        binary += "0011";
                        break;

                    case '4':
                        binary += "0100";
                        break;

                    case '5':
                        binary += "0101";
                        break;

                    case '6':
                        binary += "0110";
                        break;

                    case '7':
                        binary += "0111";
                        break;

                    case '8':
                        binary += "1000";
                        break;

                    case '9':
                        binary += "1001";
                        break;

                    case 'A':
                        binary += "1010";
                        break;

                    case 'B':
                        binary += "1011";
                        break;

                    case 'C':
                        binary += "1100";
                        break;

                    case 'D':
                        binary += "1101";
                        break;

                    case 'E':
                        binary += "1110";
                        break;

                    case 'F':
                        binary += "1111";
                        break;
                }
            }
            return binary;
        }

        //convert binary to hexadecimal and return
        public string ConvertBinaryToHexadecimal(string binary)
        {
            string hexadecimal = "";
            for (int i = 0; i < binary.Length; i += 4)
            {
                switch (binary.Substring(i, 4))
                {
                    case "0000":
                        hexadecimal += "0";
                        break;

                    case "0001":
                        hexadecimal += "1";
                        break;

                    case "0010":
                        hexadecimal += "2";
                        break;

                    case "0011":
                        hexadecimal += "3";
                        break;

                    case "0100":
                        hexadecimal += "4";
                        break;

                    case "0101":
                        hexadecimal += "5";
                        break;

                    case "0110":
                        hexadecimal += "6";
                        break;

                    case "0111":
                        hexadecimal += "7";
                        break;

                    case "1000":
                        hexadecimal += "8";
                        break;

                    case "1001":
                        hexadecimal += "9";
                        break;

                    case "1010":
                        hexadecimal += "A";
                        break;

                    case "1011":
                        hexadecimal += "B";
                        break;

                    case "1100":
                        hexadecimal += "C";
                        break;

                    case "1101":
                        hexadecimal += "D";
                        break;

                    case "1110":
                        hexadecimal += "E";
                        break;

                    case "1111":
                        hexadecimal += "F";
                        break;
                }
            }
            return hexadecimal;
        }

        // return the path of the application
        public string GetApplicationPath()
        {
            string strPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            strPath = strPath.Substring(6, strPath.Length - 6);
            return strPath;
        }

        //get the iso8583 message
        public string GetMessage(string iso8583)
        {
            string strMessage = "";
            string strBitmap = GetMessageBitmap(iso8583);
            for (int i = 0; i < strBitmap.Length; i++)
            {
                if (strBitmap[i] == '1')
                {
                    strMessage += iso8583.Substring(i * 2 + 16, 2) + " ";
                }
            }
            return strMessage;
        }

        //open Auttar.txt file and read the data and return the line starting with a number
        public List<string> GetAuttarWithLineNumber()
        {
            List<string> list = new List<string>();
            string line;
            string firstchar;
            StreamReader sr = new StreamReader(GetApplicationPath() + "\\" + "Auttar.txt");
            int lineNumber = 20;
            for (int i = 0; i < lineNumber; i++)
            {
                line = sr.ReadLine();
                //get the first character of the line
                if (!string.IsNullOrEmpty(line))
                {
                    firstchar = line.Substring(0, 2);
                    if (line != null && IsNumber(firstchar) && line.Contains("-"))
                    {
                        list.Add(line);
                    }
                }
            }
            sr.Close();
            return list;
        }

        //create a function to detect if the string is a number
        public bool IsNumber(string str)
        {
            str = str.Trim();
            int i;
            if (int.TryParse(str, out i))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // get the text in auttar.txt bellow the text informed
        public string GetAuttarContent(string text)
        {
            string line;
            string firstchar;
            StreamReader sr = new StreamReader(GetApplicationPath() + "\\" + "Auttar.txt");
            for (int i = 0; i < 20; i++)
            {
                line = sr.ReadLine();
                //get the first character of the line
                if (!string.IsNullOrEmpty(line))
                {
                    firstchar = line.Substring(0, 2);
                    if (line != null && IsNumber(firstchar) && line.Contains("-"))
                    {
                        if (line.Contains(text))
                        {
                            line = sr.ReadLine();
                            sr.Close();
                            return line;
                        }
                    }
                }
            }
            sr.Close();
            return "";
        }

        // interpret the iso8583 message
        public string InterpretMessage(string iso8583)
        {
            string strMessage = "";
            string strBitmap = GetMessageBitmap(iso8583);
            for (int i = 0; i < strBitmap.Length; i++)
            {
                if (strBitmap[i] == '1')
                {
                    strMessage += iso8583.Substring(i * 2 + 16, 2) + " ";
                }
            }
            return strMessage;
        }

        //get message type indicator
        public string GetMessageTypeIndicator(string iso8583)
        {
            string strMessageTypeIndicator = "";
            string strBitmap = GetMessageBitmap(iso8583);
            for (int i = 0; i < strBitmap.Length; i++)
            {
                if (strBitmap[i] == '1')
                {
                    strMessageTypeIndicator += iso8583.Substring(i * 2 + 16, 2);
                }
            }
            return strMessageTypeIndicator;
        }

        public string GetMTIMessageTypeIndicador(string iso8583)
        {
            // get the first position of the string
            var firstPosition = iso8583.Substring(0, 1);
            if (firstPosition == "0")
            {
                return "ISO 8583:1987 version";
            }
            else if (firstPosition == "1")
            {
                return "ISO 8583:1993 version";
            }
            else
            {
                return "Reserved for ISO use";
            }
        }

        public string GetOtherMessageFields(string iso8583)
        {
            // get the second position of the string
            var secondPosition = iso8583.Substring(1, 1);
            if (secondPosition == "0")
            {
                return "No other fields";
            }
            else if (secondPosition == "1")
            {
                return "64 (or 128) bits indicando a presença de outros campos";
            }
            else
            {
                return "Reserved for future use";
            }
        }

        //get message class
        public string GetMessageClass(string iso8583)
        {
            string strMessageClass = "";
            var secondPosition = iso8583.Substring(5, 1);
            if (secondPosition == "1")
            {
                return "Authorization message - 1";
            }
            else if (secondPosition == "2")
            {
                return "Financial message - 2";
            }
            else if (secondPosition == "3")
            {
                return "File Actions Message - 3 ";
            }
            else if (secondPosition == "4")
            {
                return "Reversal message";
            }
            else if (secondPosition == "5")
            {
                return "Reconciliation Message";
            }
            else if (secondPosition == "6")
            {
                return "Administrative Message";
            }
            else if (secondPosition == "7")
            {
                return "Fee Collections Message";
            }
            else if (secondPosition == "8")
            {
                return "Network Management Message";
            }
            else if (secondPosition == "9")
            {
                return "Reserved for ISO use";  //Reserved for ISO use
            }
            else
            {
                return "Reserved for future use";
            }
            return strMessageClass;
        }
    

    // Get message sub classes
        public string GetMessageSubClass(string iso8583)
        {
            string strMessageSubClass = "";
            var secondPosition = iso8583.Substring(6, 2);
            if (secondPosition == "00")
            {
                return "Requires approval from issuer";
            }
            else if (secondPosition == "10")
            {
                return "Response from a previous request from the issuer"; //Response from a previous request
            }
            else if (secondPosition == "20")
            {
                return "Request for advice";
            }
            else if (secondPosition == "30")
            {
                return "Request for advice - response";
            }
            else if (secondPosition == "40")
            {
                return "Notification";
            }
            else if (secondPosition == "50")
            {
                return "Reserved for future use";
            }
            else if (secondPosition == "60")
            {
                return "Reserved for future use";
            }
            else if (secondPosition == "70")
            {
                return "Reserved for future use";
            }
            else if (secondPosition == "80")
            {
                return "Reserved for future use";
            }
            else if (secondPosition == "90")
            {
                return "Reserved for future use";
            }
            else
            {
                return "Reserved for future use";
            }
            return strMessageSubClass;
        }

        // get Hexadecimal from the 8th position until 64th position
        public string GetMessageBitmap(string iso8583)
        {
            string strMessageBitmap = "";
            for (int i = 8; i < 64; i++)
            {
                strMessageBitmap += iso8583.Substring(i, 1);
            }
            return strMessageBitmap;
        } 

        // convert hexadecimal to bit 
        public string HexToBit(string hex)
        {
            string bit = "";
            for (int i = 0; i < hex.Length; i++)
            {
                switch (hex[i])
                {
                    case '0':
                        bit += "0000";
                        break;
                    case '1':
                        bit += "0001";
                        break;
                    case '2':
                        bit += "0010";
                        break;
                    case '3':
                        bit += "0011";
                        break;
                    case '4':
                        bit += "0100";
                        break;
                    case '5':
                        bit += "0101";
                        break;
                    case '6':
                        bit += "0110";
                        break;
                    case '7':
                        bit += "0111";
                        break;
                    case '8':
                        bit += "1000";
                        break;
                    case '9':
                        bit += "1001";
                        break;
                    case 'A':
                        bit += "1010";
                        break;
                    case 'B':
                        bit += "1011";
                        break;
                    case 'C':
                        bit += "1100";
                        break;
                    case 'D':
                        bit += "1101";
                        break;
                    case 'E':
                        bit += "1110";
                        break;
                    case 'F':
                        bit += "1111";
                        break;
                }
            }
            return bit;
        }

        // check fields presence
        public string CheckFieldsPresence(string bitmap)
        {
            string strFieldsPresence = "";
            for (int i = 0; i < bitmap.Length; i++)
            {
                if (bitmap[i] == '1')
                {
                    strFieldsPresence += " Campo " + (i + 1) + " esta presente | " ;
                }
            }
            return strFieldsPresence;
        }

        // get ISO-defined data elements  
        public string GetDataElements(string iso8583)
        {
            string strDataElements = "";
            var bitmap = GetMessageBitmap(iso8583);
            var bitmapBinary = HexToBit(bitmap);
            var bitmapBinaryArray = bitmapBinary.ToCharArray();
            for (int i = 0; i < bitmapBinaryArray.Length; i++)
            {
                if (bitmapBinaryArray[i] == '1')
                {
                    strDataElements += "Campo " + (i + 1) + ": " + GetDataElement(iso8583, i + 1) + " | ";
                }
            }
            return strDataElements;
        }

        // GetDataElement get Data Element from the message
        public string GetDataElement(string iso8583, int fieldNumber)
        {
            string strDataElement = "";
            var bitmap = GetMessageBitmap(iso8583);
            var bitmapBinary = HexToBit(bitmap);
            var bitmapBinaryArray = bitmapBinary.ToCharArray();
            if (bitmapBinaryArray[fieldNumber - 1] == '1')
            {
                var fieldLength = GetFieldLength(iso8583, fieldNumber);
                var fieldData = iso8583.Substring(GetFieldPosition(iso8583, fieldNumber), fieldLength);
                strDataElement = fieldData;
            }
            return strDataElement;
        }

        // GetFieldLength get field length from the message
        public int GetFieldLength(string iso8583, int fieldNumber)
        {
            try
            {
                var bitmap = GetMessageBitmap(iso8583);
                var bitmapBinary = HexToBit(bitmap);
                var bitmapBinaryArray = bitmapBinary.ToCharArray();
                var fieldLength = 0;
                if (bitmapBinaryArray[fieldNumber - 1] == '1')
                {
                    var fieldLengthHex = iso8583.Substring(GetFieldPosition(iso8583, fieldNumber), 2);
                    fieldLength = Convert.ToInt32(fieldLengthHex, 16);
                }
                return fieldLength;
            }
            catch (Exception)
            {

                return 0;
            }
            
        }

        // GetFieldPosition get field position from the message
        public int GetFieldPosition(string iso8583, int fieldNumber)
        {
            var bitmap = GetMessageBitmap(iso8583);
            var bitmapBinary = HexToBit(bitmap);
            var bitmapBinaryArray = bitmapBinary.ToCharArray();
            var fieldPosition = 0;
            if (bitmapBinaryArray[fieldNumber - 1] == '1')
            {
                var fieldPositionHex = iso8583.Substring(8, 2);
                fieldPosition = Convert.ToInt32(fieldPositionHex, 16);
                for (int i = 0; i < fieldNumber - 1; i++)
                {
                    if (bitmapBinaryArray[i] == '1')
                    {
                        if (GetFieldLength(iso8583, i + 1) > 0)
                        {
                            fieldPosition += GetFieldLength(iso8583, i + 1);
                        }
                        else
                        { 
                            return fieldPosition;
                        }

                    }
                }
            }
            return fieldPosition;
        }


    }
}