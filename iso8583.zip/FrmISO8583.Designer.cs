﻿
namespace Iso8583
{
    partial class FrmISO8583
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPayload = new System.Windows.Forms.Label();
            this.txtPayload = new System.Windows.Forms.TextBox();
            this.btnMap = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMessageTypeIndicator = new System.Windows.Forms.TextBox();
            this.txtMessageSubFunction = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBitMap = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblBitmapSecundario = new System.Windows.Forms.Label();
            this.txtSecondaryBitMapIndicator = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.btnGenerate200Message = new System.Windows.Forms.Button();
            this.btnLoadPreDefinitions = new System.Windows.Forms.Button();
            this.lstAuttar = new System.Windows.Forms.ListBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnBreakDownMessage = new System.Windows.Forms.Button();
            this.lblInterpretation = new System.Windows.Forms.Label();
            this.lblFieldsPresence = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPayload
            // 
            this.lblPayload.AutoSize = true;
            this.lblPayload.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPayload.Location = new System.Drawing.Point(12, 9);
            this.lblPayload.Name = "lblPayload";
            this.lblPayload.Size = new System.Drawing.Size(61, 18);
            this.lblPayload.TabIndex = 0;
            this.lblPayload.Text = "Payload";
            // 
            // txtPayload
            // 
            this.txtPayload.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayload.Location = new System.Drawing.Point(15, 48);
            this.txtPayload.Name = "txtPayload";
            this.txtPayload.Size = new System.Drawing.Size(1108, 24);
            this.txtPayload.TabIndex = 1;
            // 
            // btnMap
            // 
            this.btnMap.Location = new System.Drawing.Point(819, 638);
            this.btnMap.Name = "btnMap";
            this.btnMap.Size = new System.Drawing.Size(120, 55);
            this.btnMap.TabIndex = 2;
            this.btnMap.Text = "Map";
            this.btnMap.UseVisualStyleBackColor = true;
            this.btnMap.Click += new System.EventHandler(this.btnMap_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(974, 638);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(120, 55);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "Message MTI Type Indicator";
            // 
            // txtMessageTypeIndicator
            // 
            this.txtMessageTypeIndicator.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMessageTypeIndicator.Location = new System.Drawing.Point(15, 111);
            this.txtMessageTypeIndicator.Name = "txtMessageTypeIndicator";
            this.txtMessageTypeIndicator.Size = new System.Drawing.Size(924, 24);
            this.txtMessageTypeIndicator.TabIndex = 6;
            // 
            // txtMessageSubFunction
            // 
            this.txtMessageSubFunction.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMessageSubFunction.Location = new System.Drawing.Point(15, 173);
            this.txtMessageSubFunction.Name = "txtMessageSubFunction";
            this.txtMessageSubFunction.Size = new System.Drawing.Size(318, 24);
            this.txtMessageSubFunction.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Message Function";
            // 
            // txtBitMap
            // 
            this.txtBitMap.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBitMap.Location = new System.Drawing.Point(15, 270);
            this.txtBitMap.Multiline = true;
            this.txtBitMap.Name = "txtBitMap";
            this.txtBitMap.Size = new System.Drawing.Size(1108, 142);
            this.txtBitMap.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "BitMaps";
            // 
            // lblBitmapSecundario
            // 
            this.lblBitmapSecundario.AutoSize = true;
            this.lblBitmapSecundario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBitmapSecundario.Location = new System.Drawing.Point(115, 249);
            this.lblBitmapSecundario.Name = "lblBitmapSecundario";
            this.lblBitmapSecundario.Size = new System.Drawing.Size(137, 18);
            this.lblBitmapSecundario.TabIndex = 11;
            this.lblBitmapSecundario.Text = "BitMap Secundario:";
            // 
            // txtSecondaryBitMapIndicator
            // 
            this.txtSecondaryBitMapIndicator.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSecondaryBitMapIndicator.Location = new System.Drawing.Point(15, 432);
            this.txtSecondaryBitMapIndicator.Name = "txtSecondaryBitMapIndicator";
            this.txtSecondaryBitMapIndicator.Size = new System.Drawing.Size(127, 24);
            this.txtSecondaryBitMapIndicator.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(182, 435);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 18);
            this.label5.TabIndex = 13;
            this.label5.Text = "Secondary BitMap Indicator";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(15, 491);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(127, 24);
            this.textBox1.TabIndex = 14;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(157, 491);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(127, 24);
            this.textBox2.TabIndex = 15;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(299, 491);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(127, 24);
            this.textBox3.TabIndex = 16;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(443, 491);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(127, 24);
            this.textBox4.TabIndex = 17;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(585, 491);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(127, 24);
            this.textBox5.TabIndex = 18;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(728, 491);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(127, 24);
            this.textBox6.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 470);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(154, 470);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 18);
            this.label6.TabIndex = 21;
            this.label6.Text = "10";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(296, 470);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 18);
            this.label7.TabIndex = 22;
            this.label7.Text = "20";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(440, 470);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 18);
            this.label8.TabIndex = 23;
            this.label8.Text = "30";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(582, 470);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 18);
            this.label9.TabIndex = 24;
            this.label9.Text = "40";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(725, 470);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 18);
            this.label10.TabIndex = 25;
            this.label10.Text = "50";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(872, 470);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 18);
            this.label11.TabIndex = 27;
            this.label11.Text = "60";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(875, 491);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(127, 24);
            this.textBox7.TabIndex = 26;
            // 
            // btnGenerate200Message
            // 
            this.btnGenerate200Message.Location = new System.Drawing.Point(648, 638);
            this.btnGenerate200Message.Name = "btnGenerate200Message";
            this.btnGenerate200Message.Size = new System.Drawing.Size(120, 55);
            this.btnGenerate200Message.TabIndex = 28;
            this.btnGenerate200Message.Text = "Gerar Mensagem 200";
            this.btnGenerate200Message.UseVisualStyleBackColor = true;
            this.btnGenerate200Message.Click += new System.EventHandler(this.btnGenerate200Message_Click);
            // 
            // btnLoadPreDefinitions
            // 
            this.btnLoadPreDefinitions.Location = new System.Drawing.Point(330, 638);
            this.btnLoadPreDefinitions.Name = "btnLoadPreDefinitions";
            this.btnLoadPreDefinitions.Size = new System.Drawing.Size(120, 55);
            this.btnLoadPreDefinitions.TabIndex = 29;
            this.btnLoadPreDefinitions.Text = "Carregar predefinições da auttar";
            this.btnLoadPreDefinitions.UseVisualStyleBackColor = true;
            this.btnLoadPreDefinitions.Click += new System.EventHandler(this.btnLoadPreDefinitions_Click);
            // 
            // lstAuttar
            // 
            this.lstAuttar.FormattingEnabled = true;
            this.lstAuttar.Location = new System.Drawing.Point(18, 554);
            this.lstAuttar.Name = "lstAuttar";
            this.lstAuttar.Size = new System.Drawing.Size(266, 134);
            this.lstAuttar.TabIndex = 30;
            this.lstAuttar.DoubleClick += new System.EventHandler(this.lstAuttar_DoubleClick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 533);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(260, 18);
            this.label12.TabIndex = 31;
            this.label12.Text = "Double click para carregar uma Auttar ";
            // 
            // btnBreakDownMessage
            // 
            this.btnBreakDownMessage.Location = new System.Drawing.Point(496, 638);
            this.btnBreakDownMessage.Name = "btnBreakDownMessage";
            this.btnBreakDownMessage.Size = new System.Drawing.Size(120, 55);
            this.btnBreakDownMessage.TabIndex = 32;
            this.btnBreakDownMessage.Text = "Interpretar Mensagem";
            this.btnBreakDownMessage.UseVisualStyleBackColor = true;
            this.btnBreakDownMessage.Click += new System.EventHandler(this.btnBreakDownMessage_Click);
            // 
            // lblInterpretation
            // 
            this.lblInterpretation.AutoSize = true;
            this.lblInterpretation.Location = new System.Drawing.Point(296, 554);
            this.lblInterpretation.Name = "lblInterpretation";
            this.lblInterpretation.Size = new System.Drawing.Size(69, 13);
            this.lblInterpretation.TabIndex = 36;
            this.lblInterpretation.Text = "Interpretation";
            // 
            // lblFieldsPresence
            // 
            this.lblFieldsPresence.AutoSize = true;
            this.lblFieldsPresence.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFieldsPresence.Location = new System.Drawing.Point(493, 432);
            this.lblFieldsPresence.Name = "lblFieldsPresence";
            this.lblFieldsPresence.Size = new System.Drawing.Size(118, 18);
            this.lblFieldsPresence.TabIndex = 33;
            this.lblFieldsPresence.Text = "Fields Presence:";
            // 
            // FrmISO8583
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1162, 749);
            this.Controls.Add(this.lblFieldsPresence);
            this.Controls.Add(this.btnBreakDownMessage);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lstAuttar);
            this.Controls.Add(this.btnLoadPreDefinitions);
            this.Controls.Add(this.btnGenerate200Message);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSecondaryBitMapIndicator);
            this.Controls.Add(this.lblBitmapSecundario);
            this.Controls.Add(this.txtBitMap);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtMessageSubFunction);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMessageTypeIndicator);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnMap);
            this.Controls.Add(this.txtPayload);
            this.Controls.Add(this.lblPayload);
            this.Name = "FrmISO8583";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ISO 8583";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPayload;
        private System.Windows.Forms.TextBox txtPayload;
        private System.Windows.Forms.Button btnMap;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMessageTypeIndicator;
        private System.Windows.Forms.TextBox txtMessageSubFunction;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBitMap;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblBitmapSecundario;
        private System.Windows.Forms.TextBox txtSecondaryBitMapIndicator;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button btnGenerate200Message;
        private System.Windows.Forms.Button btnLoadPreDefinitions;
        private System.Windows.Forms.ListBox lstAuttar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnBreakDownMessage;
        private System.Windows.Forms.Label lblInterpretation;
        private System.Windows.Forms.Label lblFieldsPresence;
    }
}

