﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Iso8583
{
    public partial class FrmISO8583 : Form
    {
        public FrmISO8583()
        {
            InitializeComponent();
        }

        private void btnMap_Click(object sender, EventArgs e)
        {
            ISO8583 iSO = new ISO8583();

            lblPayload.Text = "Payload Length: " + this.txtPayload.Text.Length.ToString();
            GetMessageIndicator(iSO);
            GetMessageFunction(iSO);

            txtBitMap.Text = iSO.ConvertHexadecimalToBinary(txtPayload.Text.Substring(11, 1));

            CheckSecondaryBitMap(iSO);

            this.txtBitMap.Text = iSO.GetMessageBitmapSecondaryBitmap(txtPayload.Text);
        }

        private void CheckSecondaryBitMap(ISO8583 iSO)
        {
            if (iSO.ConvertHexadecimalToBinary(txtPayload.Text.Substring(9, 1)) == "1000")
            {
                this.lblBitmapSecundario.Text = " --> BitMap Secundario: Sim";
                txtSecondaryBitMapIndicator.Text = "1000";
            }
            else
            {
                this.lblBitmapSecundario.Text = " --> BitMap Secundario: Nao";
                txtSecondaryBitMapIndicator.Text = "0000";
            }
        }

        public void GetMessageIndicator(ISO8583 iSO)
        {
            txtMessageTypeIndicator.Text = iSO.GetMessageType(txtPayload.Text) + " - " +
                                                       iSO.GetMessageValue(txtPayload.Text, 4, 4);
        }

        private void GetMessageFunction(ISO8583 iSO)
        {
            txtMessageSubFunction.Text = iSO.GetMessageFunction(txtPayload.Text) + " - " +
                                                  iSO.GetMessageValue(txtPayload.Text, 6, 1);
        }

        // Break down iso8583 message into fields
        public string DecodeIso8583(string iso8583)
        {
            string str1st = iso8583.Substring(0, 4);
            string str2nd = iso8583.Substring(4, 4);
            string charMap = iso8583.Substring(8, 32);
            string strMap1 = charMap.Substring(0, 16);
            string strMap2 = charMap.Substring(16, 16);
            return str1st + " " + str2nd + " " + strMap1 + " " + strMap2;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void btnGenerate200Message_Click(object sender, EventArgs e)
        {
            // generate iso8583 0200 message
            ISO8583 iSO = new ISO8583();
            txtPayload.Text = iSO.Generate0200Message();
        }

        private void btnLoadPreDefinitions_Click(object sender, EventArgs e)
        {
            ISO8583 iSO8583 = new ISO8583();
            List<string> itens =  new List<string>();
            itens = iSO8583.GetAuttarWithLineNumber();
            lstAuttar.DataSource = itens;

        }

        private void lstAuttar_DoubleClick(object sender, EventArgs e)
        {
            
            // open Auttar file
            ISO8583 iSO8583 = new ISO8583();

            // get the message below the selected line 
            var selectText = lstAuttar.SelectedItem;
            txtPayload.Text = iSO8583.GetAuttarContent(selectText.ToString());


            
        }

        private void btnBreakDownMessage_Click(object sender, EventArgs e)
        {
            ISO8583 iSO8583 = new ISO8583();
            // break down the message

            this.txtMessageTypeIndicator.Text = iSO8583.GetMTIMessageTypeIndicador(this.txtPayload.Text);

            this.txtMessageTypeIndicator.Text = this.txtMessageTypeIndicator.Text + " - " +
                                                iSO8583.GetOtherMessageFields(this.txtPayload.Text) + " - " +
                                                iSO8583.GetMessageClass(this.txtPayload.Text) + " - " +
                                                iSO8583.GetMessageSubClass(this.txtPayload.Text);


            this.txtBitMap.Text = iSO8583.GetMessageBitmap(txtPayload.Text);
            // add new line
            this.txtBitMap.Text = this.txtBitMap.Text + Environment.NewLine;

            // call the convert hexa to bitmap function 
            this.txtBitMap.Text = this.txtBitMap.Text +
                                  iSO8583.ConvertHexadecimalToBinary(txtPayload.Text.Substring(9, 1));

            // check if a secondary bitmap is present 
            CheckSecondaryBitMap(iSO8583);

            var result = iSO8583.CheckFieldsPresence(this.txtPayload.Text);
            this.txtBitMap.Text = this.txtBitMap.Text + Environment.NewLine + " Campos Present.: " + result;

            // call tthe GetDataElements function 
            this.txtBitMap.Text = this.txtBitMap.Text + Environment.NewLine + " Elementos de dados: " +
                                  iSO8583.GetDataElements(this.txtPayload.Text);

        }
    }
}